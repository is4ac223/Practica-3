package controladorDao.persona;

import contrladorLista.DynamicList;
import controlador.Utiles.Utiles;
import controladorDao.DaoImplement;
import emptyException.EmptyException;
import java.lang.reflect.Field;
import modelo.Compra;

public class CompraControl extends DaoImplement<Compra> {

        private Compra compra;
        private DynamicList<Compra> compras;

        public CompraControl() {
                super(Compra.class);
        }

        public Compra getCompra() {
                if (compra == null) {
                        compra = new Compra();
                }
                return compra;
        }

        public void setCompra(Compra compra) {
                this.compra = compra;
        }

        public DynamicList<Compra> getCompras() {
                compras = all();
                return compras;
        }

        public void setCompras(DynamicList<Compra> compras) {
                this.compras = compras;
        }

        public DynamicList<Compra> ordenar(DynamicList<Compra> lista, Integer tipo, String field, String criterio) throws EmptyException, Exception {
                Integer n = lista.getLength();
                Compra[] compraT = lista.toArray();
                Field attribute = Utiles.getField(Compra.class, field);
                if (attribute != null) {
                        for (int i = 0; i < n - 1; i++) {
                                int k = i;
                                Compra t = compraT[i];
                                for (int j = i + 1; j < n; j++) {
                                        if (compraT[j].compare(t, criterio, tipo)) {
                                                t = compraT[j];
                                                k = j;
                                        }
                                }
                                compraT[k] = compraT[i];
                                compraT[i] = t;
                        }
                } else {
                        throw new Exception("No existe el criterio de busqueda");
                }
                return lista.toList(compraT);
        }

        public DynamicList<Compra> quickSort(DynamicList<Compra> lista, Integer tipo, String criterio) throws EmptyException, Exception {
                Integer longitudLista = lista.getLength();
                Compra[] compras = lista.toArray();

                if (longitudLista > 1) {
                        int posicionPivote = partirArreglo(compras, tipo, criterio);

                        DynamicList<Compra> ladoIzquierdo = new DynamicList<>();
                        DynamicList<Compra> ladoDerecho = new DynamicList<>();

                        for (int i = 0; i < posicionPivote; i++) {
                                ladoIzquierdo.add(compras[i]);
                        }

                        for (int i = posicionPivote + 1; i < longitudLista; i++) {
                                ladoDerecho.add(compras[i]);
                        }

                        DynamicList<Compra> ladoIzquierdOrdenado = quickSort(ladoIzquierdo, tipo, criterio);
                        DynamicList<Compra> ladoDerechOrdenado = quickSort(ladoDerecho, tipo, criterio);

                        ladoIzquierdOrdenado.add(compras[posicionPivote]);
                        for (int i = 0; i < ladoDerechOrdenado.getLength(); i++) {
                                ladoIzquierdOrdenado.add(ladoDerechOrdenado.getInfo(i));
                        }

                        return ladoIzquierdOrdenado;
                } else {
                        return lista;
                }
        }

        public int partirArreglo(Compra[] arreglo, Integer tipo, String field) {
                Compra t = arreglo[arreglo.length - 1];
                int i = -1;
                for (int j = 0; j < arreglo.length - 1; j++) {
                        if (arreglo[j].compare(t, field, tipo)) {
                                i++;
                                cambiar(arreglo, i, j);
                        }
                }
                cambiar(arreglo, i + 1, arreglo.length - 1);
                return i + 1;
        }

        public void cambiar(Compra[] arreglo, int i, int j) {
                Compra aux = arreglo[i];
                arreglo[i] = arreglo[j];
                arreglo[j] = aux;
        }

        public DynamicList<Compra> shellSort(DynamicList<Compra> lista, Integer tipo, String criterio) throws EmptyException, Exception {
                int lengthLista = lista.getLength();
                Compra[] compras = lista.toArray();
                int tamanio = lengthLista / 2;
                while (tamanio > 0) {
                        for (int i = tamanio; i < lengthLista; i++) {
                                Compra t = compras[i];
                                int j = i;
                                while (j >= tamanio && compras[j - tamanio].compare(t, criterio, tipo)) {
                                        compras[j] = compras[j - tamanio];
                                        j -= tamanio;
                                }
                                compras[j] = t;
                        }
                        tamanio = tamanio / 2;
                }
                return lista.toList(compras);
        }

        public DynamicList<Compra> buscar(String texto, DynamicList<Compra> lista, String field, String criterio) {
                DynamicList<Compra> auxList = new DynamicList<>();
                try {
                        Compra[] aux = ordenar(lista, 0, field, criterio).toArray();
                        System.out.println("Pasaste");
                        for (Compra c : aux) {
                                switch (criterio) {
                                        case "Nombre":
                                                if (c.getPersona().getNombre().toLowerCase().contains(texto.toLowerCase())) {
                                                        auxList.add(c);
                                                        break;
                                                }
                                        case "Dni":
                                                if (c.getPersona().getDni().toLowerCase().contains(texto.toLowerCase())) {
                                                        auxList.add(c);
                                                        break;
                                                }
                                        case "Origen":
                                                if (c.getBoleto().getOrigen().toLowerCase().contains(texto.toLowerCase())) {
                                                        auxList.add(c);
                                                        break;
                                                }
                                        case "Destino":
                                                if ((c.getBoleto().getDestino().toLowerCase().contains(texto.toLowerCase()))) {
                                                        auxList.add(c);
                                                        break;
                                                }
                                        default:
                                                break;
                                }
                        }
                } catch (Exception e) {
                        System.out.println("Error en buscar " + e.getMessage());
                }
                return auxList;
        }

        public DynamicList<Compra> buscarLineal(String texto, DynamicList<Compra> lista, String field, String criterio) {
                DynamicList<Compra> auxList = new DynamicList<>();
                try {
                        Compra[] aux = ordenar(lista, 0, field, criterio).toArray();
                        for (Compra c : aux) {
                                switch (criterio) {
                                        case "Nombre":
                                                if (c.getPersona().getNombre().toLowerCase().contains(texto.toLowerCase())) {
                                                        auxList.add(c);
                                                        break;
                                                }
                                                break;
                                        case "Dni":
                                                if (c.getPersona().getDni().toLowerCase().contains(texto.toLowerCase())) {
                                                        auxList.add(c);
                                                        break;
                                                }
                                                break;
                                        case "Origen":
                                                if (c.getBoleto().getOrigen().toLowerCase().contains(texto.toLowerCase())) {
                                                        auxList.add(c);
                                                        break;
                                                }
                                                break;
                                        case "Destino":
                                                if (c.getBoleto().getDestino().toLowerCase().contains(texto.toLowerCase())) {
                                                        auxList.add(c);
                                                        break;
                                                }
                                                break;
                                        default:
                                                break;
                                }
                        }
                } catch (Exception e) {
                        System.out.println("Error en buscarLineal " + e.getMessage());
                }
                return auxList;
        }

        public DynamicList<Compra> buscarBinaria(String texto, DynamicList<Compra> lista, String field, String criterio) {
                DynamicList<Compra> auxList = new DynamicList<>();
                try {
                        Compra[] aux = ordenar(lista, 0, field, criterio).toArray();
                        System.out.println("Pasaste");
                        int low = 0;
                        int high = aux.length - 1;
                        while (low <= high) {
                                int mid = low + (high - low) / 2;
                                for (Compra c : aux) {
                                        switch (criterio) {
                                                case "Nombre":
                                                        if (c.getPersona().getNombre().toLowerCase().contains(texto.toLowerCase())) {
                                                                auxList.add(c);
                                                                return auxList;  // Se encontró una coincidencia, se puede terminar la búsqueda.
                                                        } else if (c.getPersona().getNombre().toLowerCase().compareTo(texto.toLowerCase()) < 0) {
                                                                low = mid + 1;
                                                        } else {
                                                                high = mid - 1;
                                                        }
                                                        break;
                                                case "Dni":
                                                        if (c.getPersona().getDni().toLowerCase().contains(texto.toLowerCase())) {
                                                                auxList.add(c);
                                                                return auxList;
                                                        } else if (c.getPersona().getDni().toLowerCase().compareTo(texto.toLowerCase()) < 0) {
                                                                low = mid + 1;
                                                        } else {
                                                                high = mid - 1;
                                                        }
                                                        break;
                                                case "Origen":
                                                        if (c.getBoleto().getOrigen().toLowerCase().contains(texto.toLowerCase())) {
                                                                auxList.add(c);
                                                                return auxList;
                                                        } else if (c.getBoleto().getOrigen().toLowerCase().compareTo(texto.toLowerCase()) < 0) {
                                                                low = mid + 1;
                                                        } else {
                                                                high = mid - 1;
                                                        }
                                                        break;
                                                case "Destino":
                                                        if (c.getBoleto().getDestino().toLowerCase().contains(texto.toLowerCase())) {
                                                                auxList.add(c);
                                                                return auxList;
                                                        } else if (c.getBoleto().getDestino().toLowerCase().compareTo(texto.toLowerCase()) < 0) {
                                                                low = mid + 1;
                                                        } else {
                                                                high = mid - 1;
                                                        }
                                                        break;
                                                default:
                                                        break;
                                        }
                                }
                        }
                } catch (Exception e) {
                        System.out.println("Error en buscarBinaria " + e.getMessage());
                }

                return auxList;
        }

}
