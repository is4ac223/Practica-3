package controladorDao.persona;

import contrladorLista.DynamicList;
import controladorDao.DaoImplement;
import emptyException.EmptyException;
import modelo.Persona;

public class PersonaControl extends DaoImplement<Persona>{

        private Persona persona = new Persona();
        private DynamicList<Persona> personas;

        public PersonaControl(Class<Persona> clazz) {
                super(clazz);
        }

        
   
    //Metodo que permite guardar
        public Boolean guardar() {
                try {
                        getPersona().setDni((getPersonas().getLength()).toString());
                        getPersonas().add(getPersona());
                        return true;
                } catch (Exception e) {
                        return false;
                }
        }

        public Integer posVerificar() throws EmptyException {
                Integer bandera = 0;
                for (Integer i = 0; i <= this.personas.getLength(); i++) {
                        if (this.getPersonas().getInfo(i) == null) {
                                bandera = i;
                                break;
                        }
                }
                return bandera;
        }

        public void imprimir() throws EmptyException {
                for (int i = 0; i < this.getPersonas().getLength(); i++) {
                        System.out.println(getPersonas().getInfo(i));
                }
        }

    /**
     * @return the persona
     */
        public Persona getPersona() {
                if (persona == null) {
                        persona = new Persona();
                }
                return persona;
        }

        public void setPersona(Persona persona) {
                this.persona = persona;
        }

        public DynamicList<Persona> getPersonas() {
                return personas;
        }

        public void setPersonas(DynamicList<Persona> personas) {
                this.personas = personas;
        }

        @Override
        public String toString() {
                return "DNI: " + getPersona().getDni()+ " Apellidos: " + getPersona().getApellido()+ " Nombres: " + getPersona().getNombre();
        }
}
