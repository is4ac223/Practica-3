package controlador;

import contrladorLista.DynamicList;
import modelo.Compra;

public class CompraControl {
        private Compra compra = new Compra();
        private DynamicList<Compra> compras;

        public CompraControl() {
                this.compras = new DynamicList<>();
        }

        public CompraControl(DynamicList<Compra> compras) {
                this.compras = compras;
        }

        public Boolean guardar() {
                try {
                        getCompras().add(getCompra());
                        return true;
                } catch (Exception e) {
                        return false;
                }
        }

        public Compra getCompra() {
                if(compra == null) {
                        compra = new Compra();
                }
                return compra;
        }

        public void setCompra(Compra compra) {
                this.compra = compra;
        }

        public DynamicList<Compra> getCompras() {
                return compras;
        }

        public void setCompras(DynamicList<Compra> compras) {
                this.compras = compras;
        }  
}
