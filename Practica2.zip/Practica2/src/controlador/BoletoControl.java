package controlador;

import contrladorLista.DynamicList;
import modelo.Boleto;

public class BoletoControl {
        private Boleto boleto;
        private DynamicList<Boleto> boletos;

        public BoletoControl() {
        }

        public BoletoControl(Boleto boleto, DynamicList<Boleto> boletos) {
                this.boleto = boleto;
                this.boletos = boletos;
        }

        public Boleto getBoleto() {
                return boleto;
        }

        public void setBoleto(Boleto boleto) {
                this.boleto = boleto;
        }

        public DynamicList<Boleto> getBoletos() {
                return boletos;
        }

        public void setBoletos(DynamicList<Boleto> boletos) {
                this.boletos = boletos;
        }
        
        
}
