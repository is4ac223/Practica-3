package modelo;

import java.time.LocalDate;

public class Boleto {
        private Double precio;
        private LocalDate fecha_Salida;
        private String destino;
        private String origen;

        public Boleto() {
        }

        public Boleto(Double precio, LocalDate fecha_Salida,String destino, String origen) {
                this.precio = precio;
                this.fecha_Salida = fecha_Salida;
                this.destino = destino;
                this.origen = origen;
        }

        public Double getPrecio() {
                return precio;
        }

        public void setPrecio(Double precio) {
                this.precio = precio;
        }

        public LocalDate getFecha_Salida() {
                return fecha_Salida;
        }

        public void setFecha_Salida(LocalDate fecha_Salida) {
                this.fecha_Salida = fecha_Salida;
        }

        public String getDestino() {
                return destino;
        }

        public void setDestino(String destino) {
                this.destino = destino;
        }

        public String getOrigen() {
                return origen;
        }

        public void setOrigen(String origen) {
                this.origen = origen;
        }
}
