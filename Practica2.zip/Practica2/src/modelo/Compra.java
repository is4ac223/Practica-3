package modelo;

import contrladorLista.DynamicList;
import java.time.LocalDate;

public class Compra {
        private DynamicList<Persona> personas;
        private Persona persona;
        private DynamicList<Boleto> boletos;
        private Boleto boleto;
        private LocalDate fecha_Venta;

        public Compra() {
        }

        public Compra(DynamicList<Persona> personas, DynamicList<Boleto> boletos, LocalDate fecha_Venta) {
                this.personas = personas;
                this.boletos = boletos;
                this.fecha_Venta = fecha_Venta;
        }

        public DynamicList<Persona> getPersonas() {
                return personas;
        }

        public void setPersonas(DynamicList<Persona> personas) {
                this.personas = personas;
        }

        public DynamicList<Boleto> getBoletos() {
                return boletos;
        }

        public void setBoletos(DynamicList<Boleto> boletos) {
                this.boletos = boletos;
        }

        public LocalDate getFecha_Venta() {
                return fecha_Venta;
        }

        public void setFecha_Venta(LocalDate fecha_Venta) {
                this.fecha_Venta = fecha_Venta;
        }

        public Persona getPersona() {
                if (persona == null) {
                        persona = new Persona();
                }
                return persona;
        }

        public void setPersona(Persona persona) {
                this.persona = persona;
        }

        public Boleto getBoleto() {
                if (boleto == null) {
                        boleto = new Boleto();
                }
                return boleto;
        }

        public void setBoleto(Boleto boleto) {
                this.boleto = boleto;
        }
        
        public Boolean compare(Compra c, String field, Integer type) {
                switch (type) {
                        case 0:
                                if (field.equalsIgnoreCase("dni")) {
                                        return persona.getDni().compareTo(c.getPersona().getDni()) < 0;
                                } else if (field.equalsIgnoreCase("nombre")) {
                                        return persona.getNombre().compareTo(c.getPersona().getNombre()) < 0;
                                } else if (field.equalsIgnoreCase("origen")) {
                                        return boleto.getOrigen().compareTo(c.getBoleto().getOrigen()) < 0;
                                } else if (field.equalsIgnoreCase("destino")) {
                                        return boleto.getDestino().compareTo(c.getBoleto().getDestino()) < 0;
                                }
                                //break;
                        case 1:
                                if (field.equalsIgnoreCase("dni")) {
                                        return persona.getDni().compareTo(c.getPersona().getDni()) > 0;
                                } else if (field.equalsIgnoreCase("nombre")) {
                                        return persona.getNombre().compareTo(c.getPersona().getNombre()) > 0;
                                } else if (field.equalsIgnoreCase("origen")) {
                                        return boleto.getOrigen().compareTo(c.getBoleto().getOrigen()) > 0;
                                } else if (field.equalsIgnoreCase("destino")) {
                                        return boleto.getDestino().compareTo(c.getBoleto().getDestino()) > 0;
                                }
                                //break;
                        default:
                                return null;
                }
        }
}
