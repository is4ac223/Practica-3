package vista;

import contrladorLista.DynamicList;
import controlador.CompraControl;
import controlador.Utiles.Utiles;
import emptyException.EmptyException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import modelo.Compra;
import vista.listas.tablas.ModeloTablaVenta;

public class frmPrincipal extends javax.swing.JFrame {

        private CompraControl compraControl = new CompraControl();
        private ModeloTablaVenta mtv = new ModeloTablaVenta();
        private controladorDao.persona.CompraControl control = new controladorDao.persona.CompraControl();

        /**
         * Creates new form frmPrincipal
         */
        public frmPrincipal() {
                initComponents();
                limpiar();
                cbxCriterioOrdenar.setEnabled(false);
        }

        private void cargarTabla() {
                mtv.setCompras(control.all());
                tblVentas.setModel(mtv);
                tblVentas.updateUI();
        }

        public void cargarCompras(DynamicList<Compra> compras) {
                mtv.setCompras(compras);
        }

        private void limpiar() {
                txtDni.setEnabled(true);
                tblVentas.clearSelection();
                txtApellido.setText(" ");
                txtDni.setText(" ");
                txtNombre.setText(" ");
                txtOrigen.setText(" ");
                txtDestino.setText(" ");
                txtDiaSalida.setText(" ");
                txtDiaVenta.setText(" ");
                txtMesSalida.setText(" ");
                txtMesVenta.setText(" ");
                txtAnioSalida.setText(" ");
                txtAnioVenta.setText(" ");
                txtPrecio.setText(" ");
                cargarTabla();
        }

        private Boolean validar() {
                return (!txtApellido.getText().trim().isEmpty()
                        && !txtDni.getText().trim().isEmpty()
                        && !txtNombre.getText().trim().isEmpty()
                        && !txtOrigen.getText().trim().isEmpty()
                        && !txtDestino.getText().trim().isEmpty()
                        && !txtDiaSalida.getText().trim().isEmpty()
                        && !txtDiaVenta.getText().trim().isEmpty()
                        && !txtMesSalida.getText().trim().isEmpty()
                        && !txtMesVenta.getText().trim().isEmpty()
                        && !txtAnioSalida.getText().trim().isEmpty()
                        && !txtAnioVenta.getText().trim().isEmpty());
        }

        private void guardar() throws emptyException.EmptyException {
                if (validar()) {
                        if (Utiles.valiDia(txtDiaSalida, txtMesSalida)) {
                                if (Utiles.valiDia(txtDiaVenta, txtMesVenta)) {
                                        compraControl.getCompra().getPersona().setDni(txtDni.getText().trim());
                                        compraControl.getCompra().getPersona().setApellido(txtApellido.getText().trim());
                                        compraControl.getCompra().getPersona().setNombre(txtNombre.getText().trim());
                                        compraControl.getCompra().getBoleto().setDestino(txtDestino.getText().trim());
                                        compraControl.getCompra().getBoleto().setOrigen(txtOrigen.getText().trim());
                                        compraControl.getCompra().getBoleto().setPrecio(Double.valueOf(txtPrecio.getText().trim()));
                                        compraControl.getCompra().getBoleto().setFecha_Salida(Utiles.pasarFecha(txtDiaSalida, txtMesSalida, txtAnioSalida));
                                        compraControl.getCompra().setFecha_Venta(Utiles.pasarFecha(txtDiaVenta, txtMesVenta, txtAnioVenta));
                                        if (compraControl.guardar()) {
                                                control.persist(compraControl.getCompra());
                                                JOptionPane.showMessageDialog(null, "Datos guardados", "Ok",
                                                        JOptionPane.INFORMATION_MESSAGE);
                                                cargarTabla();
                                                limpiar();
                                                compraControl.setCompra(null);
                                        } else {
                                                JOptionPane.showMessageDialog(null, "No se pudo guardar, hubo un error", "ERROR",
                                                        JOptionPane.ERROR_MESSAGE);
                                        }
                                } else {
                                        JOptionPane.showMessageDialog(null, "El número de dias en fecha de venta es incorrecto", "Fecha de venta",
                                                JOptionPane.ERROR_MESSAGE);
                                }
                        } else {
                                JOptionPane.showMessageDialog(null, "El número de dias en fecha de salida es incorrecto", "Fecha de salida",
                                        JOptionPane.ERROR_MESSAGE);
                        }
                } else {
                        JOptionPane.showMessageDialog(null, "Falta llenar campos", "Error", JOptionPane.ERROR_MESSAGE);
                }
        }

        private void ordenar() throws Exception {
                String field = cbxCriterio.getSelectedItem().toString();
                String criterio = cbxCriterioOrdenar.getSelectedItem().toString();
                Integer tipo = 0;
                if (btn_Tipo.isSelected()) {
                        tipo = 1;
                }
                try {
                        mtv.setCompras(control.ordenar(control.getCompras(), tipo, field, criterio));
                        tblVentas.setModel(mtv);
                        tblVentas.updateUI();
                } catch (Exception e) {
                        JOptionPane.showMessageDialog(null, e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                }
        }

        private void ordenarQS() throws Exception {
                String criterio = cbxCriterioOrdenar.getSelectedItem().toString();
                Integer tipo = 0;
                if (btn_Tipo.isSelected()) {
                        tipo = 1;
                }
                try {
                        mtv.setCompras(control.quickSort(control.getCompras(), tipo, criterio));
                        tblVentas.setModel(mtv);
                        tblVentas.updateUI();
                } catch (Exception e) {
                        JOptionPane.showMessageDialog(null, e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                }
        }

        private void ordenarSS() throws Exception {
                String field = cbxCriterio.getSelectedItem().toString();
                String criterio = cbxCriterioOrdenar.getSelectedItem().toString();
                Integer tipo = 1;
                if (btn_Tipo.isSelected()) {
                        tipo = 0;
                }
                try {
                        mtv.setCompras(control.shellSort(control.getCompras(), tipo, criterio));
                        tblVentas.setModel(mtv);
                        tblVentas.updateUI();
                } catch (Exception e) {
                        JOptionPane.showMessageDialog(null, e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                }
        }
        
        
        private void buscar(){
                String field = cbxCriterio.getSelectedItem().toString();
                String criterio = cbxCriterioOrdenar.getSelectedItem().toString();
                String texto = txtBuscar.getText();
                try {
                        mtv.setCompras(control.buscar(texto, control.getCompras(), field, criterio));
                        tblVentas.setModel(mtv);
                        tblVentas.updateUI();
                } catch (Exception e) {
                        JOptionPane.showMessageDialog(null, e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                }
        }

        private void busquedaLineal(){
                String field = cbxCriterio.getSelectedItem().toString();
                String criterio = cbxCriterioOrdenar.getSelectedItem().toString();
                String texto = txtBuscar.getText();
                try {
                        mtv.setCompras(control.buscarLineal(texto, control.getCompras(), field, criterio));
                        tblVentas.setModel(mtv);
                        tblVentas.updateUI();
                } catch (Exception e) {
                        JOptionPane.showMessageDialog(null, e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                }
        }

        
        
        
        private void busquedaBinaria(){
                String field = cbxCriterio.getSelectedItem().toString();
                String criterio = cbxCriterioOrdenar.getSelectedItem().toString();
                String texto = txtBuscar.getText();
                try {
                        mtv.setCompras(control.buscarBinaria(texto, control.getCompras(), field, criterio));
                        tblVentas.setModel(mtv);
                        tblVentas.updateUI();
                } catch (Exception e) {
                        JOptionPane.showMessageDialog(null, e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                }
        }
        
        private void nroBoletosVendidos() {
                Integer aux = tblVentas.getRowCount();
                txtBoletosVendidos.setEditable(false);
                txtBoletosVendidos.setText(aux.toString());
        }

        public void ventaTotalBoletos() {
                Double aux = 0.0;
                for (int i = 0; i < tblVentas.getRowCount(); i++) {
                        aux = aux + Double.valueOf((tblVentas.getValueAt(i, 5)).toString());
                }
                txtCalcularVenta.setEditable(false);
                txtCalcularVenta.setText(aux.toString());
        }

        public void cargarCriterios() {
                String aux = cbxCriterio.getSelectedItem().toString();
                cbxCriterioOrdenar.setEnabled(true);
                if (aux.equalsIgnoreCase("persona")) {
                        cbxCriterioOrdenar.addItem("Nombre");
                        cbxCriterioOrdenar.addItem("Dni");
                }
                if (aux.equalsIgnoreCase("boleto")) {
                        cbxCriterioOrdenar.addItem("Origen");
                        cbxCriterioOrdenar.addItem("Destino");
                }
        }

        public void limpiarCriterios() {
                int aux = cbxCriterioOrdenar.getItemCount();
                for (int i = 0; i < aux; i++) {
                        cbxCriterioOrdenar.removeItemAt(0);
                }
                cbxCriterioOrdenar.setEnabled(false);
        }

        @SuppressWarnings("unchecked")
        // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
        private void initComponents() {

                jPanel1 = new javax.swing.JPanel();
                jLabel1 = new javax.swing.JLabel();
                jPanel2 = new javax.swing.JPanel();
                jLabel2 = new javax.swing.JLabel();
                jLabel4 = new javax.swing.JLabel();
                jLabel5 = new javax.swing.JLabel();
                jLabel6 = new javax.swing.JLabel();
                txtNombre = new javax.swing.JTextField();
                txtApellido = new javax.swing.JTextField();
                txtDni = new javax.swing.JTextField();
                jPanel3 = new javax.swing.JPanel();
                jLabel3 = new javax.swing.JLabel();
                jLabel7 = new javax.swing.JLabel();
                jLabel8 = new javax.swing.JLabel();
                jLabel9 = new javax.swing.JLabel();
                jLabel10 = new javax.swing.JLabel();
                jLabel11 = new javax.swing.JLabel();
                jLabel12 = new javax.swing.JLabel();
                jLabel13 = new javax.swing.JLabel();
                txtOrigen = new javax.swing.JTextField();
                txtDestino = new javax.swing.JTextField();
                txtDiaVenta = new javax.swing.JTextField();
                txtMesVenta = new javax.swing.JTextField();
                txtAnioVenta = new javax.swing.JTextField();
                jLabel17 = new javax.swing.JLabel();
                txtDiaSalida = new javax.swing.JTextField();
                jLabel18 = new javax.swing.JLabel();
                txtMesSalida = new javax.swing.JTextField();
                jLabel19 = new javax.swing.JLabel();
                txtAnioSalida = new javax.swing.JTextField();
                jLabel14 = new javax.swing.JLabel();
                txtPrecio = new javax.swing.JTextField();
                btnGuardar = new javax.swing.JButton();
                jScrollPane1 = new javax.swing.JScrollPane();
                tblVentas = new javax.swing.JTable();
                jLabel15 = new javax.swing.JLabel();
                jLabel16 = new javax.swing.JLabel();
                txtBoletosVendidos = new javax.swing.JTextField();
                btnBoletosVendidos = new javax.swing.JButton();
                jLabel20 = new javax.swing.JLabel();
                txtCalcularVenta = new javax.swing.JTextField();
                jLabel21 = new javax.swing.JLabel();
                btnCalcularVenta = new javax.swing.JButton();
                jLabel22 = new javax.swing.JLabel();
                cbxCriterio = new javax.swing.JComboBox<>();
                btn_Tipo = new javax.swing.JCheckBox();
                btnOrdenar = new javax.swing.JButton();
                jLabel23 = new javax.swing.JLabel();
                cbxCriterioOrdenar = new javax.swing.JComboBox<>();
                btnOpciones = new javax.swing.JButton();
                btnLimpiarCriterios = new javax.swing.JButton();
                btnQuickSort = new javax.swing.JButton();
                btnShellSort = new javax.swing.JButton();
                jLabel24 = new javax.swing.JLabel();
                txtBuscar = new javax.swing.JTextField();
                btnBuscar = new javax.swing.JButton();
                btnBuscarLineal = new javax.swing.JButton();
                btnBuscarBinario = new javax.swing.JButton();

                setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

                jPanel1.setBorder(javax.swing.BorderFactory.createEtchedBorder());

                jLabel1.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
                jLabel1.setText("VENTA DE BOLETOS");

                jPanel2.setBorder(javax.swing.BorderFactory.createEtchedBorder());

                jLabel2.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
                jLabel2.setText("Datos Pasajero");
                jLabel2.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));

                jLabel4.setFont(new java.awt.Font("Dialog", 1, 12)); // NOI18N
                jLabel4.setText("Nombre:");

                jLabel5.setFont(new java.awt.Font("Dialog", 1, 12)); // NOI18N
                jLabel5.setText("Apellido:");

                jLabel6.setFont(new java.awt.Font("Dialog", 1, 12)); // NOI18N
                jLabel6.setText("DNI:");

                javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
                jPanel2.setLayout(jPanel2Layout);
                jPanel2Layout.setHorizontalGroup(
                        jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(jLabel2)
                                .addGap(0, 0, Short.MAX_VALUE))
                        .addGroup(jPanel2Layout.createSequentialGroup()
                                .addContainerGap()
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addGroup(jPanel2Layout.createSequentialGroup()
                                                .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(txtNombre, javax.swing.GroupLayout.PREFERRED_SIZE, 193, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGroup(jPanel2Layout.createSequentialGroup()
                                                .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(txtApellido))
                                        .addGroup(jPanel2Layout.createSequentialGroup()
                                                .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(txtDni)))
                                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                );
                jPanel2Layout.setVerticalGroup(
                        jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(jLabel2)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(jLabel4)
                                        .addComponent(txtNombre, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(jLabel5)
                                        .addComponent(txtApellido, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(jLabel6)
                                        .addComponent(txtDni, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addContainerGap(10, Short.MAX_VALUE))
                );

                jPanel3.setBorder(javax.swing.BorderFactory.createEtchedBorder());

                jLabel3.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
                jLabel3.setText("Datos Boleto");

                jLabel7.setFont(new java.awt.Font("Dialog", 1, 12)); // NOI18N
                jLabel7.setText("Origen:");

                jLabel8.setFont(new java.awt.Font("Dialog", 1, 12)); // NOI18N
                jLabel8.setText("Destino:");

                jLabel9.setFont(new java.awt.Font("Dialog", 1, 12)); // NOI18N
                jLabel9.setText("Fecha de venta");

                jLabel10.setFont(new java.awt.Font("Dialog", 1, 12)); // NOI18N
                jLabel10.setText("Dia:");

                jLabel11.setFont(new java.awt.Font("Dialog", 1, 12)); // NOI18N
                jLabel11.setText("Mes:");

                jLabel12.setFont(new java.awt.Font("Dialog", 1, 12)); // NOI18N
                jLabel12.setText("Año:");

                jLabel13.setFont(new java.awt.Font("Dialog", 1, 12)); // NOI18N
                jLabel13.setText("Fecha de salida");

                txtOrigen.addActionListener(new java.awt.event.ActionListener() {
                        public void actionPerformed(java.awt.event.ActionEvent evt) {
                                txtOrigenActionPerformed(evt);
                        }
                });

                txtDiaVenta.addActionListener(new java.awt.event.ActionListener() {
                        public void actionPerformed(java.awt.event.ActionEvent evt) {
                                txtDiaVentaActionPerformed(evt);
                        }
                });

                txtMesVenta.addActionListener(new java.awt.event.ActionListener() {
                        public void actionPerformed(java.awt.event.ActionEvent evt) {
                                txtMesVentaActionPerformed(evt);
                        }
                });

                txtAnioVenta.addActionListener(new java.awt.event.ActionListener() {
                        public void actionPerformed(java.awt.event.ActionEvent evt) {
                                txtAnioVentaActionPerformed(evt);
                        }
                });

                jLabel17.setFont(new java.awt.Font("Dialog", 1, 12)); // NOI18N
                jLabel17.setText("Dia:");

                jLabel18.setFont(new java.awt.Font("Dialog", 1, 12)); // NOI18N
                jLabel18.setText("Mes:");

                txtMesSalida.addActionListener(new java.awt.event.ActionListener() {
                        public void actionPerformed(java.awt.event.ActionEvent evt) {
                                txtMesSalidaActionPerformed(evt);
                        }
                });

                jLabel19.setFont(new java.awt.Font("Dialog", 1, 12)); // NOI18N
                jLabel19.setText("Año:");

                txtAnioSalida.addActionListener(new java.awt.event.ActionListener() {
                        public void actionPerformed(java.awt.event.ActionEvent evt) {
                                txtAnioSalidaActionPerformed(evt);
                        }
                });

                jLabel14.setFont(new java.awt.Font("Dialog", 1, 12)); // NOI18N
                jLabel14.setText("Precio:");

                javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
                jPanel3.setLayout(jPanel3Layout);
                jPanel3Layout.setHorizontalGroup(
                        jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel3Layout.createSequentialGroup()
                                .addContainerGap()
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addGroup(jPanel3Layout.createSequentialGroup()
                                                        .addComponent(jLabel7)
                                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                        .addComponent(txtOrigen, javax.swing.GroupLayout.PREFERRED_SIZE, 206, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                .addGroup(jPanel3Layout.createSequentialGroup()
                                                        .addComponent(jLabel8)
                                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                        .addComponent(txtDestino))
                                                .addComponent(jLabel9)
                                                .addGroup(jPanel3Layout.createSequentialGroup()
                                                        .addGap(26, 26, 26)
                                                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                                .addGroup(jPanel3Layout.createSequentialGroup()
                                                                        .addComponent(jLabel10)
                                                                        .addGap(18, 18, 18)
                                                                        .addComponent(txtDiaVenta, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                                        .addGap(18, 18, 18)
                                                                        .addComponent(jLabel14, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                                .addGroup(jPanel3Layout.createSequentialGroup()
                                                                        .addComponent(jLabel11)
                                                                        .addGap(12, 12, 12)
                                                                        .addComponent(txtMesVenta, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                                        .addGap(18, 18, 18)
                                                                        .addComponent(txtPrecio, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                                        .addComponent(jLabel13)
                                        .addGroup(jPanel3Layout.createSequentialGroup()
                                                .addGap(23, 23, 23)
                                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                                .addGroup(jPanel3Layout.createSequentialGroup()
                                                                        .addComponent(jLabel17)
                                                                        .addGap(18, 18, 18)
                                                                        .addComponent(txtDiaSalida, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                                .addGroup(jPanel3Layout.createSequentialGroup()
                                                                        .addComponent(jLabel18)
                                                                        .addGap(12, 12, 12)
                                                                        .addComponent(txtMesSalida, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                                .addGroup(jPanel3Layout.createSequentialGroup()
                                                                        .addComponent(jLabel19)
                                                                        .addGap(12, 12, 12)
                                                                        .addComponent(txtAnioSalida, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                                        .addGroup(jPanel3Layout.createSequentialGroup()
                                                                .addComponent(jLabel12)
                                                                .addGap(12, 12, 12)
                                                                .addComponent(txtAnioVenta, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                );
                jPanel3Layout.setVerticalGroup(
                        jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel3Layout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(jLabel3)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(jLabel7)
                                        .addComponent(txtOrigen, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(jLabel8)
                                        .addComponent(txtDestino, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(18, 18, 18)
                                .addComponent(jLabel9)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(jLabel10)
                                        .addComponent(txtDiaVenta, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jLabel14))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(txtMesVenta, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jLabel11)
                                        .addComponent(txtPrecio, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(txtAnioVenta, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jLabel12))
                                .addGap(12, 12, 12)
                                .addComponent(jLabel13)
                                .addGap(18, 18, 18)
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(jLabel17)
                                        .addComponent(txtDiaSalida, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(txtMesSalida, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jLabel18))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(txtAnioSalida, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jLabel19))
                                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                );

                btnGuardar.setFont(new java.awt.Font("Dialog", 3, 12)); // NOI18N
                btnGuardar.setText("Guardar");
                btnGuardar.addActionListener(new java.awt.event.ActionListener() {
                        public void actionPerformed(java.awt.event.ActionEvent evt) {
                                btnGuardarActionPerformed(evt);
                        }
                });

                tblVentas.setModel(new javax.swing.table.DefaultTableModel(
                        new Object [][] {
                                {null, null, null, null, null, null},
                                {null, null, null, null, null, null},
                                {null, null, null, null, null, null},
                                {null, null, null, null, null, null}
                        },
                        new String [] {
                                "Title 1", "Title 2", "Title 3", "Title 4", "Title 5", "Title 6"
                        }
                ));
                jScrollPane1.setViewportView(tblVentas);

                jLabel15.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
                jLabel15.setText("Nro Boletos:");

                jLabel16.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
                jLabel16.setText("VENTA DE BOLETOS");

                btnBoletosVendidos.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
                btnBoletosVendidos.setText("Número de boletos vendidos");
                btnBoletosVendidos.addActionListener(new java.awt.event.ActionListener() {
                        public void actionPerformed(java.awt.event.ActionEvent evt) {
                                btnBoletosVendidosActionPerformed(evt);
                        }
                });

                jLabel20.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
                jLabel20.setText("Total Boletos:");

                jLabel21.setText("$");

                btnCalcularVenta.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
                btnCalcularVenta.setText("Calcular venta boletos");
                btnCalcularVenta.addActionListener(new java.awt.event.ActionListener() {
                        public void actionPerformed(java.awt.event.ActionEvent evt) {
                                btnCalcularVentaActionPerformed(evt);
                        }
                });

                jLabel22.setText("Que ordenar/ buscar:");

                cbxCriterio.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Persona", "Boleto" }));
                cbxCriterio.setToolTipText("");
                cbxCriterio.addActionListener(new java.awt.event.ActionListener() {
                        public void actionPerformed(java.awt.event.ActionEvent evt) {
                                cbxCriterioActionPerformed(evt);
                        }
                });

                btn_Tipo.setText("Descendente");

                btnOrdenar.setText("Ordenar");
                btnOrdenar.addActionListener(new java.awt.event.ActionListener() {
                        public void actionPerformed(java.awt.event.ActionEvent evt) {
                                btnOrdenarActionPerformed(evt);
                        }
                });

                jLabel23.setText("Criterio ordenar/buscar:");

                cbxCriterioOrdenar.setToolTipText("");
                cbxCriterioOrdenar.addActionListener(new java.awt.event.ActionListener() {
                        public void actionPerformed(java.awt.event.ActionEvent evt) {
                                cbxCriterioOrdenarActionPerformed(evt);
                        }
                });

                btnOpciones.setText("Opciones");
                btnOpciones.addActionListener(new java.awt.event.ActionListener() {
                        public void actionPerformed(java.awt.event.ActionEvent evt) {
                                btnOpcionesActionPerformed(evt);
                        }
                });

                btnLimpiarCriterios.setText("Limpiar ");
                btnLimpiarCriterios.addActionListener(new java.awt.event.ActionListener() {
                        public void actionPerformed(java.awt.event.ActionEvent evt) {
                                btnLimpiarCriteriosActionPerformed(evt);
                        }
                });

                btnQuickSort.setText("QuickSort");
                btnQuickSort.addActionListener(new java.awt.event.ActionListener() {
                        public void actionPerformed(java.awt.event.ActionEvent evt) {
                                btnQuickSortActionPerformed(evt);
                        }
                });

                btnShellSort.setText("ShellSort");
                btnShellSort.addActionListener(new java.awt.event.ActionListener() {
                        public void actionPerformed(java.awt.event.ActionEvent evt) {
                                btnShellSortActionPerformed(evt);
                        }
                });

                jLabel24.setText("Buscar:");

                btnBuscar.setText("Buscar");
                btnBuscar.addActionListener(new java.awt.event.ActionListener() {
                        public void actionPerformed(java.awt.event.ActionEvent evt) {
                                btnBuscarActionPerformed(evt);
                        }
                });

                btnBuscarLineal.setText("Lineal");
                btnBuscarLineal.addActionListener(new java.awt.event.ActionListener() {
                        public void actionPerformed(java.awt.event.ActionEvent evt) {
                                btnBuscarLinealActionPerformed(evt);
                        }
                });

                btnBuscarBinario.setText("Binaria");
                btnBuscarBinario.addActionListener(new java.awt.event.ActionListener() {
                        public void actionPerformed(java.awt.event.ActionEvent evt) {
                                btnBuscarBinarioActionPerformed(evt);
                        }
                });

                javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
                jPanel1.setLayout(jPanel1Layout);
                jPanel1Layout.setHorizontalGroup(
                        jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addGroup(jPanel1Layout.createSequentialGroup()
                                                .addGap(26, 26, 26)
                                                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 185, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGroup(jPanel1Layout.createSequentialGroup()
                                                .addContainerGap()
                                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                        .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                        .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                        .addGroup(jPanel1Layout.createSequentialGroup()
                                                                .addGap(6, 6, 6)
                                                                .addComponent(btnGuardar)))
                                                .addGap(18, 18, 18)
                                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                        .addComponent(jScrollPane1)
                                                        .addGroup(jPanel1Layout.createSequentialGroup()
                                                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                                        .addGroup(jPanel1Layout.createSequentialGroup()
                                                                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                                                        .addGroup(jPanel1Layout.createSequentialGroup()
                                                                                                .addComponent(jLabel15, javax.swing.GroupLayout.PREFERRED_SIZE, 96, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                                                                .addComponent(txtBoletosVendidos, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                                                        .addComponent(btnBoletosVendidos))
                                                                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                                                        .addGroup(jPanel1Layout.createSequentialGroup()
                                                                                                .addGap(48, 48, 48)
                                                                                                .addComponent(btnCalcularVenta, javax.swing.GroupLayout.PREFERRED_SIZE, 168, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                                                        .addGroup(jPanel1Layout.createSequentialGroup()
                                                                                                .addGap(26, 26, 26)
                                                                                                .addComponent(jLabel20)
                                                                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                                                                .addComponent(txtCalcularVenta, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                                                                .addComponent(jLabel21))))
                                                                        .addGroup(jPanel1Layout.createSequentialGroup()
                                                                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                                                        .addGroup(jPanel1Layout.createSequentialGroup()
                                                                                                .addGap(86, 86, 86)
                                                                                                .addComponent(btnLimpiarCriterios)
                                                                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                                                                .addComponent(btn_Tipo, javax.swing.GroupLayout.PREFERRED_SIZE, 108, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED))
                                                                                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                                                                                .addComponent(jLabel23)
                                                                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                                                                .addComponent(cbxCriterioOrdenar, javax.swing.GroupLayout.PREFERRED_SIZE, 96, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                                                                .addGap(52, 52, 52)))
                                                                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                                                                        .addComponent(btnQuickSort, javax.swing.GroupLayout.DEFAULT_SIZE, 87, Short.MAX_VALUE)
                                                                                        .addComponent(btnShellSort, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                                                        .addComponent(btnOrdenar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                                                                .addGap(92, 92, 92)
                                                                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                                                                        .addComponent(btnBuscar, javax.swing.GroupLayout.DEFAULT_SIZE, 75, Short.MAX_VALUE)
                                                                                        .addComponent(btnBuscarLineal, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                                                        .addComponent(btnBuscarBinario, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                                                                        .addGroup(jPanel1Layout.createSequentialGroup()
                                                                                .addComponent(jLabel22)
                                                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                                                .addComponent(cbxCriterio, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                                                .addGap(18, 18, 18)
                                                                                .addComponent(btnOpciones)
                                                                                .addGap(107, 107, 107)
                                                                                .addComponent(jLabel24, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                                                .addComponent(txtBuscar, javax.swing.GroupLayout.PREFERRED_SIZE, 144, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                                                .addGap(0, 113, Short.MAX_VALUE)))))
                                .addContainerGap())
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                .addGap(0, 0, Short.MAX_VALUE)
                                .addComponent(jLabel16, javax.swing.GroupLayout.PREFERRED_SIZE, 185, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(273, 273, 273))
                );
                jPanel1Layout.setVerticalGroup(
                        jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel1Layout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(jLabel1)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel16)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                        .addGroup(jPanel1Layout.createSequentialGroup()
                                                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                .addComponent(btnGuardar))
                                        .addGroup(jPanel1Layout.createSequentialGroup()
                                                .addGap(10, 10, 10)
                                                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 314, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                                        .addComponent(jLabel22)
                                                        .addComponent(cbxCriterio, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                        .addComponent(btnOpciones)
                                                        .addComponent(jLabel24)
                                                        .addComponent(txtBuscar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                                        .addComponent(jLabel23)
                                                        .addComponent(cbxCriterioOrdenar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                        .addComponent(btnOrdenar)
                                                        .addComponent(btnBuscar))
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                                        .addComponent(btnLimpiarCriterios)
                                                        .addComponent(btn_Tipo)
                                                        .addComponent(btnShellSort)
                                                        .addComponent(btnBuscarLineal))
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                                        .addComponent(btnQuickSort)
                                                        .addComponent(btnBuscarBinario))
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                                        .addComponent(jLabel15)
                                                        .addComponent(txtBoletosVendidos, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                        .addComponent(jLabel20)
                                                        .addComponent(txtCalcularVenta, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                        .addComponent(jLabel21))
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                                        .addComponent(btnBoletosVendidos)
                                                        .addComponent(btnCalcularVenta))))
                                .addContainerGap(33, Short.MAX_VALUE))
                );

                javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
                getContentPane().setLayout(layout);
                layout.setHorizontalGroup(
                        layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addContainerGap())
                );
                layout.setVerticalGroup(
                        layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                );

                pack();
        }// </editor-fold>//GEN-END:initComponents

        private void txtAnioVentaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtAnioVentaActionPerformed
                // TODO add your handling code here:
        }//GEN-LAST:event_txtAnioVentaActionPerformed

        private void txtMesVentaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtMesVentaActionPerformed
                // TODO add your handling code here:    
        }//GEN-LAST:event_txtMesVentaActionPerformed

        private void txtMesSalidaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtMesSalidaActionPerformed
                // TODO add your handling code here:
        }//GEN-LAST:event_txtMesSalidaActionPerformed

        private void txtAnioSalidaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtAnioSalidaActionPerformed
                // TODO add your handling code here:
        }//GEN-LAST:event_txtAnioSalidaActionPerformed

        private void txtOrigenActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtOrigenActionPerformed
                // TODO add your handling code here:
        }//GEN-LAST:event_txtOrigenActionPerformed

        private void btnGuardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGuardarActionPerformed
                try {
                        guardar();
                } catch (EmptyException ex) {
                        Logger.getLogger(frmPrincipal.class.getName()).log(Level.SEVERE, null, ex);
                }
        }//GEN-LAST:event_btnGuardarActionPerformed

        private void txtDiaVentaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtDiaVentaActionPerformed
                // TODO add your handling code here:
        }//GEN-LAST:event_txtDiaVentaActionPerformed

        private void btnBoletosVendidosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBoletosVendidosActionPerformed
                nroBoletosVendidos();
        }//GEN-LAST:event_btnBoletosVendidosActionPerformed

        private void btnCalcularVentaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCalcularVentaActionPerformed
                ventaTotalBoletos();
        }//GEN-LAST:event_btnCalcularVentaActionPerformed

        private void cbxCriterioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbxCriterioActionPerformed
                // TODO add your handling code here:
        }//GEN-LAST:event_cbxCriterioActionPerformed

        private void btnOrdenarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnOrdenarActionPerformed
                try {
                        ordenar();
                } catch (Exception ex) {
                        Logger.getLogger(frmPrincipal.class.getName()).log(Level.SEVERE, null, ex);
                }
        }//GEN-LAST:event_btnOrdenarActionPerformed

        private void cbxCriterioOrdenarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbxCriterioOrdenarActionPerformed
                // TODO add your handling code here:
        }//GEN-LAST:event_cbxCriterioOrdenarActionPerformed

        private void btnOpcionesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnOpcionesActionPerformed
                cargarCriterios();
        }//GEN-LAST:event_btnOpcionesActionPerformed

        private void btnLimpiarCriteriosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLimpiarCriteriosActionPerformed
                limpiarCriterios();
        }//GEN-LAST:event_btnLimpiarCriteriosActionPerformed

        private void btnQuickSortActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnQuickSortActionPerformed
                try {
                        ordenarQS();
                } catch (Exception ex) {
                        Logger.getLogger(frmPrincipal.class.getName()).log(Level.SEVERE, null, ex);
                }
        }//GEN-LAST:event_btnQuickSortActionPerformed

        private void btnShellSortActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnShellSortActionPerformed
                try {
                        ordenarSS();
                } catch (Exception ex) {
                        Logger.getLogger(frmPrincipal.class.getName()).log(Level.SEVERE, null, ex);
                }
        }//GEN-LAST:event_btnShellSortActionPerformed

        private void btnBuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuscarActionPerformed
                buscar();
        }//GEN-LAST:event_btnBuscarActionPerformed

        private void btnBuscarLinealActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuscarLinealActionPerformed
                busquedaLineal();
        }//GEN-LAST:event_btnBuscarLinealActionPerformed

        private void btnBuscarBinarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuscarBinarioActionPerformed
                busquedaBinaria();
        }//GEN-LAST:event_btnBuscarBinarioActionPerformed

        /**
         * @param args the command line arguments
         */
        public static void main(String args[]) {
                /* Set the Nimbus look and feel */
                //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
                /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
                 */
                try {
                        for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                                if ("Nimbus".equals(info.getName())) {
                                        javax.swing.UIManager.setLookAndFeel(info.getClassName());
                                        break;
                                }
                        }
                } catch (ClassNotFoundException ex) {
                        java.util.logging.Logger.getLogger(frmPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
                } catch (InstantiationException ex) {
                        java.util.logging.Logger.getLogger(frmPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
                } catch (IllegalAccessException ex) {
                        java.util.logging.Logger.getLogger(frmPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
                } catch (javax.swing.UnsupportedLookAndFeelException ex) {
                        java.util.logging.Logger.getLogger(frmPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
                }
                //</editor-fold>

                /* Create and display the form */
                java.awt.EventQueue.invokeLater(new Runnable() {
                        public void run() {
                                frmPrincipal prin = new frmPrincipal();
                                prin.setVisible(true);
                                prin.setLocationRelativeTo(null);
                        }
                });
        }

        // Variables declaration - do not modify//GEN-BEGIN:variables
        private javax.swing.JButton btnBoletosVendidos;
        private javax.swing.JButton btnBuscar;
        private javax.swing.JButton btnBuscarBinario;
        private javax.swing.JButton btnBuscarLineal;
        private javax.swing.JButton btnCalcularVenta;
        private javax.swing.JButton btnGuardar;
        private javax.swing.JButton btnLimpiarCriterios;
        private javax.swing.JButton btnOpciones;
        private javax.swing.JButton btnOrdenar;
        private javax.swing.JButton btnQuickSort;
        private javax.swing.JButton btnShellSort;
        private javax.swing.JCheckBox btn_Tipo;
        private javax.swing.JComboBox<String> cbxCriterio;
        private javax.swing.JComboBox<String> cbxCriterioOrdenar;
        private javax.swing.JLabel jLabel1;
        private javax.swing.JLabel jLabel10;
        private javax.swing.JLabel jLabel11;
        private javax.swing.JLabel jLabel12;
        private javax.swing.JLabel jLabel13;
        private javax.swing.JLabel jLabel14;
        private javax.swing.JLabel jLabel15;
        private javax.swing.JLabel jLabel16;
        private javax.swing.JLabel jLabel17;
        private javax.swing.JLabel jLabel18;
        private javax.swing.JLabel jLabel19;
        private javax.swing.JLabel jLabel2;
        private javax.swing.JLabel jLabel20;
        private javax.swing.JLabel jLabel21;
        private javax.swing.JLabel jLabel22;
        private javax.swing.JLabel jLabel23;
        private javax.swing.JLabel jLabel24;
        private javax.swing.JLabel jLabel3;
        private javax.swing.JLabel jLabel4;
        private javax.swing.JLabel jLabel5;
        private javax.swing.JLabel jLabel6;
        private javax.swing.JLabel jLabel7;
        private javax.swing.JLabel jLabel8;
        private javax.swing.JLabel jLabel9;
        private javax.swing.JPanel jPanel1;
        private javax.swing.JPanel jPanel2;
        private javax.swing.JPanel jPanel3;
        private javax.swing.JScrollPane jScrollPane1;
        private javax.swing.JTable tblVentas;
        private javax.swing.JTextField txtAnioSalida;
        private javax.swing.JTextField txtAnioVenta;
        private javax.swing.JTextField txtApellido;
        private javax.swing.JTextField txtBoletosVendidos;
        private javax.swing.JTextField txtBuscar;
        private javax.swing.JTextField txtCalcularVenta;
        private javax.swing.JTextField txtDestino;
        private javax.swing.JTextField txtDiaSalida;
        private javax.swing.JTextField txtDiaVenta;
        private javax.swing.JTextField txtDni;
        private javax.swing.JTextField txtMesSalida;
        private javax.swing.JTextField txtMesVenta;
        private javax.swing.JTextField txtNombre;
        private javax.swing.JTextField txtOrigen;
        private javax.swing.JTextField txtPrecio;
        // End of variables declaration//GEN-END:variables
}
