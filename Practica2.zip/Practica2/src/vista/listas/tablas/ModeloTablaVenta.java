package vista.listas.tablas;

import contrladorLista.DynamicList;
import emptyException.EmptyException;
import javax.swing.table.AbstractTableModel;
import modelo.Compra;

public class ModeloTablaVenta extends AbstractTableModel {

        private DynamicList<Compra> compras;

        public DynamicList<Compra> getCompras() {
                return compras;
        }

        public void setCompras(DynamicList<Compra> list) {
                this.compras = list;
        }

        @Override
        public int getRowCount() {
                return compras.getLength();
        }

        @Override
        public int getColumnCount() {
                return 6;
        }

        @Override
        public Object getValueAt(int rowIndex, int columnIndex) {
                try {
                        Compra c = compras.getInfo(rowIndex);
                        switch (columnIndex) {
                                case 0: return (c != null) ? c.getPersona().getDni(): " ";
                                case 1: return (c != null) ? c.getPersona().getApellido()+ " " + c.getPersona().getNombre(): "";
                                case 2: return (c != null) ? c.getBoleto().getFecha_Salida(): "";
                                case 3: return (c != null) ? c.getFecha_Venta(): "";
                                case 4: return (c != null) ? c.getBoleto().getOrigen()+ " -" + c.getBoleto().getDestino(): "";
                                case 5: return (c != null) ? c.getBoleto().getPrecio(): " ";
                                default:
                                        return null;
                                }
                        } catch (EmptyException ex) {
                return null;
                }
        }

        @Override
        public String getColumnName(int column) {
                switch (column) {
                        case 0: return "DNI";
                        case 1: return "USUARIO";
                        case 2: return "Fecha de Salida";
                        case 3: return "Fecha de Venta";
                        case 4: return "Origen-Destino";
                        case 5: return "Precio($)";
                        default:
                                return null;
                }
        }
}
